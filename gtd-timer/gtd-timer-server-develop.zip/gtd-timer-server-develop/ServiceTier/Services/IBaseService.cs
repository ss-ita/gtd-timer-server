﻿namespace ServiceTier.Services
{
    public interface IBaseService
    {
    }
}