﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Timer.DAL.Timer.DAL.Repositories
{
    public interface IUserManager
    {

    }
}
