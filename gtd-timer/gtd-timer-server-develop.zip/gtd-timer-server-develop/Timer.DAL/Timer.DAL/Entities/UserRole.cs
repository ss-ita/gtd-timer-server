﻿using Microsoft.AspNetCore.Identity;

namespace Timer.DAL.Timer.DAL.Entities
{
    public class UserRole : IdentityUserRole<int>
    {

    }
}
