﻿using Microsoft.AspNetCore.Identity;

namespace Timer.DAL.Timer.DAL.Entities
{
    public class Role : IdentityRole<int>
    {

    }
}
