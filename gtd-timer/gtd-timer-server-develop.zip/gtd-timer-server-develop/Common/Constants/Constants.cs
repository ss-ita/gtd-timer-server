﻿namespace Common.Constant
{
    public class Constants
    {
        public const string SecretKey = "This is my custom Secret key for authnetication";
        public const string RequiredUser = "Username is required";
        public const string CorectEmail = "example33@gmail.com";
        public const string CorectPassword = "1234567";
    }
}
